'use strict';

/* jasmine specs for controllers go here */

describe('LogCtrl', function(){
  var myCtrl1;

  beforeEach(function(){
    myCtrl1 = new LogCtrl();
  });


  it('should ....', function() {
    //spec body
  });
});


describe('LogCtrl', function(){
  var myCtrl2;


  beforeEach(function(){
    myCtrl2 = new LogCtrl();
  });


  it('should ....', function() {
    //spec body
  });
});
