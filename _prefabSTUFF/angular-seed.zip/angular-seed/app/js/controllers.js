'use strict';

/* Controllers */


function HomeCtrl() {

}
HomeCtrl.$inject = [];

function LogCtrl(logFactory) {
    var logLevel1 = logFactory('level 1');
    var logLevel1_1 = logFactory('level 1_1', logLevel1);
    var logLevel1_2 = logFactory('level 1_2', logLevel1);
    var logLevel1_1_1 = logFactory('level 1_1_1', logLevel1_1);
    logLevel1.log('one');
    logLevel1_1.log('two');
    logLevel1_2.log('three');
    logLevel1_1_1.log('four');

    logLevel1.debug('debug');
    logLevel1_1.info('info');
    logLevel1_2.warn('warn');
    logLevel1_1_1.error('error');
}
//LogCtrl.$inject = ['logFactory'];
