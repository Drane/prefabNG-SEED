'use strict';

/* Services */


// Demonstrate how to register services
// In this case it is a simple value service.
angular.module('myApp.services', []).
    value('version', '0.1').
    value('logFactory_whiteList', /.*/).
    //value('logFactory_whiteList', /!|.*Ctrl|run/).
    value('logFactory_piercingMethods', {warn: true, error: true}).
    factory('logFactory', ['$log', 'logFactory_whiteList' , 'logFactory_piercingMethods', function ($log, whiteList, piercing) {
        piercing = piercing || {};
        whiteList = whiteList || /.*/;

        return function (prefix, parentLog) {
            var log = parentLog || $log;
            var match = prefix.match(whiteList);

            function e(fnName) {
                if (!log[fnName]) {
                    fnName = 'log';
                }

                return (piercing[fnName] || match)
                    ? log[fnName].bind(log, '[' + prefix + ']')//,'[' + angular.uppercase(fnName) + ']')
                    : angular.noop;
            }

            return ({
                debug: e('debug').bind(e('debug'), '[DEBUG]'),//debug: e('debug'),
                info: e('info').bind(e('debug'), '[INFO]'),
                log: e('log').bind(e('debug'), '[LOG]'),
                warn: e('warn').bind(e('debug'), '[WARN]'),
                error: e('error').bind(e('debug'), '[ERROR]')
            });
        };
    }]);