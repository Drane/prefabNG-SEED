'use strict';


// Declare app level module which depends on filters, and services
angular.module('myApp', ['myApp.filters', 'myApp.services', 'myApp.directives']).
    value('version', '0.1').

    config(['$routeProvider', function ($routeProvider, logFactory) {
        var log = logFactory('routeProvider');
        log.info('test');
        $routeProvider.when('/view1', {templateUrl: 'partials/home.html', controller: HomeCtrl});
        $routeProvider.when('/view2', {templateUrl: 'partials/log.html', controller: LogCtrl});
        $routeProvider.otherwise({redirectTo: '/view1'});
    }]);
